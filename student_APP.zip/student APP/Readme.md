# University Student App

## Introduction
University Student App is a web application designed to cater to the needs of university students. It provides essential functionalities such as user authentication, a personalized dashboard with timetable management, and event tracking.

## Features
- **User Authentication:** Secure signup and login system for users.
- **Dashboard:** Personalized dashboard displaying user-specific information like timetable and upcoming events.
- **Timetable Management:** Allows users to view  their class schedules.
- **Events Tracking:** Keeps users informed about university events and enables them to manage their participation.

## Installation
To run the University Student App locally, follow these steps:

1. Download and unzip the project files from the provided ZIP archive.

2. Open Android Studio and select "Open an existing Android Studio project" from the welcome screen.

3. Navigate to the directory where you unzipped the project files and select the root folder of the project.

4. Android Studio will start importing the project. This process may take a few moments.

5. Once the project is imported, ensure that all dependencies are resolved. Android Studio will automatically download any missing dependencies.

6. Connect your Android device to your computer using a USB cable or use an Android emulator provided by Android Studio.

7. Build and run the app by clicking the "Run" button in the Android Studio toolbar. Select your target device or emulator from the list.

8. The app will be installed and launched on your device/emulator. You can now interact with the University Student App.

## Technologies Used

- **Android Studio**: Integrated Development Environment (IDE) for Android app development.
- **Java**: Programming language used for Android app development.
- **XML**: Markup language used for designing user interface layouts in Android.
- **Firebase Authentication**: Firebase authentication service used for user authentication and authorization.

## Contributors

-[Hureen Awais]




